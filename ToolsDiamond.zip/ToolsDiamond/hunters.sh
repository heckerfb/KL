clear
echo
python2 meizu.py
echo
clear
echo
ungu='\033[35;1m'
pu='\033[1;97m'
ijo='\033[1;92m'
me='\033[1;91m'
cyan='\033[36;1m'
sleep 1.5
figlet -f slant "SELAMAT.." | lolcat
figlet -f slant "MENCOBA!!" | lolcat
sleep 3
clear
echo $ungu══════════════════════════════════════════════════════════
figlet -f slant "LABALABA" | lolcat
echo $ungu══════════════════════════════════════════════════════════
echo $ungu"
\033[1;95m█████████
\033[1;93m█▄█████▄█      \033[1;91m●▬▬▬▬▬▬▬▬▬๑۩۩๑▬▬▬▬▬▬▬▬●
\033[1;93m█\033[1;92m▼▼▼▼▼ \033[1;92m- _ --_--\033[1;95m╔╦╗┌─┐┬─┐┬┌─   ╔═╗╔╗ 
\033[1;93m█ \033[1;92m \033[1;92m_-_-- -_ --__\033[1;92m ║║├─┤├┬┘├┴┐───╠╣ ╠╩╗
\033[1;93m█\033[1;92m▲▲▲▲▲\033[1;92m--  - _ --\033[1;96m═╩╝┴ ┴┴└─┴ ┴   ╚  ╚═╝ \033[1;96m{tools-Diamond}
\033[1;93m█████████      \033[1;92m«----------✧----------»
\033[1;93m ██ ██
\033[1;96m╔═══════════════════════════════════════════╗
\033[1;96m║\033[1;96m¤ \033[1;93mMaker   \033[1;93m: \033[1;93mMr_Hunters  \033[1;93m                   ║
\033[1;96m║\033[1;96m¤ \033[1;93mWa  \033[1;93m    : \033[1;93m\033[4m083847277532\033[0m \033[1;93m                  ║
\033[1;96m║\033[1;96m¤ \033[1;93mEmail  \033[1;93m : \033[1;93m\033[4mgelasajur1204@gmail.com\033[0m \033[1;93m       ║
\033[1;96m╚═══════════════════════════════════════════╝
"""

sleep 2

echo $ungu"
╔▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ \033[1;96m{Bang Hunters Punya}$ungu ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
║
║=>$ijo[+]$ungu Install dlu bahan2nya boz q $ijo"✔"$ungu
║
║=>[$pu"1"$ungu] Dark BHV26 $ijo"✔"$ungu
║
║=>[$pu"2"$ungu] Dark cyber2.5 $ijo"✔"$ungu
║
║=>[$pu"3"$ungu] Dark-vpro $ijo"✔"$ungu
║
║=>[$pu"4"$ungu] Dark PREMIUM New $ijo"✔"$ungu
║
║=>[$pu"5"$ungu] Dark setan $ijo"✔"$ungu
║
║=>[$pu"6"$ungu] Dark 3.1 $ijo"✔"$ungu
║
║=>[$pu"7"$ungu] Dark v2 $ijo"✔"$ungu
║
║=>[$pu"8"$ungu] Diamond-1 $ijo"✔"$ungu
║
║=>[$pu"9"$ungu] Diamond-2 $ijo"✔"$ungu
║
║=>[$pu"10"$ungu] Dark Iblis $ijo"✔"$ungu
║
║=>[$pu"11"$ungu] Premium tok $ijo"✔"$ungu
║
║=>[$pu"12"$ungu] Prov1 $ijo"✔"$ungu
║
║=>[$pu"13"$ungu] V1.2-master $ijo"✔"$ungu
║
║=>[$pu"14"$ungu] Vip-2.1 $ijo"✔"$ungu
║
┗────[$pu 99 $ungu] exit $me✘"
echo "\033[35;1m"
read -p "root@Pilih Nomor > " bro
if [ $bro = 0 ] || [ $bro]
then
clear
pkg install ruby
gem install lolcat
pip2 install requests
pip2 install mechanize
pip2 install requirements
sh yasin.sh
fi

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
pkg install git
git clone  https://github.com/pashayogi/SETAN
cd SETAN
python2 SETAN.py
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
pkg install git
git clone https://github.com/muhalvin/darkfb7
cd darkfb7
python2 dark.py
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
pkg install git
git clone https://github.com/Mr-XsZ/Dark-Fb
cd Dark-Fb
python2 dark.py
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
pkg install git
git clone https://github.com/TheMagizz/DarkPremium
cd DarkPremium
python2 DarkFB.py
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
pkg install git
git clone https://github.com/m4rche3ll-cyber/dark-vpro
cd dark-vpro
python2 dark-vpro.py
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
git clone https://github.com/wira2611/Pro2611
cd Pro2611
python2 Pro.py
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
git clone https://github.com/wira2611/diamon
ls
cd diamon
ls
python2 diamond-1.py
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
git clone https://github.com/cyber2611/v1.2
ls
cd v1.2
ls
python2 Dragon-v1.2.py
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
git clone https://github.com/cyber2611/v2-dark
cd v2.dark
ls
python2 v2.dark.py
if

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
git clone https://github.com/cyber2611/dark-cyber11
cd dark-cyber11
ls
python2 kapten.py
if

if [ $bro = 11 ] || [ $bro = 11 ]
then
clear
git clone https://github.com/cyber2611/cyber2.5
cd cyber2.5
ls
python2 Premium2.5.py
if

if [ $bro = 12 ] || [ $bro = 12 ]
then
clear
git clone https://github.com/cyber2611/IBLI2
cd IBLI2
ls
python2 dark-iblis.py
if

if [ $bro = 13 ] || [ $bro = 13 ]
then
clear
git clone https://github.com/cyber2611/dark-asu
cd dark-asu
ls
python2 kimak.py
if

if if [ $bro = 14 ] || [ $bro = 14 ]
then
clear
git clone https://github.com/cyber2611/BHV26
cd BHV26
ls
python2 vip-1.9.py
if

if [ $bro = 15 ] || [ $bro = 15 ]
then
clear
git clone https://github.com/cyber2611/Mr.RENDY
cd Mr.RENDY
ls
python2 Mr.rendy.py
if

if [ $bro = 99 ] || [ $bro = 99 ]
then
echo $cyan  "We Are Family"
sleep 1
exit
fi
